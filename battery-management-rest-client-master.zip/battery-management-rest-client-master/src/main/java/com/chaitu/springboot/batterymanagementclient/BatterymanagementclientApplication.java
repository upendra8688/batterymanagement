package com.chaitu.springboot.batterymanagementclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BatterymanagementclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(BatterymanagementclientApplication.class, args);
	}

}
