package com.chaitu.springboot.batterymanagementclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatterymanagementclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
